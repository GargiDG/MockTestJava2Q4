package com.gargi.interfaceexample;

public class Rectangle implements Drawable {

	@Override
	public void draw() {
		System.out.println("Drawing a rectangle");

	}

}
