package com.gargi.interfaceexample;

public interface Drawable {
    void draw();
}