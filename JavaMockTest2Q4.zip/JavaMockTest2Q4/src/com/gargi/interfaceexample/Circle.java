package com.gargi.interfaceexample;

public class Circle implements Drawable {

	@Override
	public void draw() {
		System.out.println("Drawing a circle");

	}

}
