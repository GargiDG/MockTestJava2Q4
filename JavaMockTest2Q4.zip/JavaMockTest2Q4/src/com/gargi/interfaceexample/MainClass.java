package com.gargi.interfaceexample;

public class MainClass {

	public static void main(String[] args) {
		 Circle circle = new Circle();
	     Rectangle rectangle = new Rectangle();

	        circle.draw();
	        rectangle.draw();

	}

}
